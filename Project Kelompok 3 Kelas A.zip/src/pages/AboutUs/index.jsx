import { Helmet } from 'react-helmet-async';
import Layout from './Layout';

export default function AboutUs() {
  return (
    <>
      <Helmet>
        <title>About Us - Bubbly</title>
      </Helmet>

      <Layout />
    </>
  );
}
