import { Helmet } from 'react-helmet-async';
import Layout from './Layout';

export default function EditShop() {
  return (
    <>
      <Helmet>
        <title>Edit Shop - Bubbly</title>
      </Helmet>

      <Layout />
    </>
  );
}
