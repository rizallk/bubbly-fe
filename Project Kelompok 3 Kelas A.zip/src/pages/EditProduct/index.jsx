import { Helmet } from 'react-helmet-async';
import Layout from './Layout';

export default function EditProduct() {
  return (
    <>
      <Helmet>
        <title>Edit Product - Bubbly</title>
      </Helmet>

      <Layout />
    </>
  );
}
