import { Helmet } from 'react-helmet-async';
import Layout from './Layout';

export default function Signup() {
  return (
    <>
      <Helmet>
        <title>Signup - Bubbly</title>
      </Helmet>

      <Layout />
    </>
  );
}
