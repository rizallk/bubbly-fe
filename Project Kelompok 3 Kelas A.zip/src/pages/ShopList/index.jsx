import { Helmet } from 'react-helmet-async';
import Layout from './Layout';

export default function ShopList() {
  return (
    <>
      <Helmet>
        <title>Shop List - Bubbly</title>
      </Helmet>

      <Layout />
    </>
  );
}
