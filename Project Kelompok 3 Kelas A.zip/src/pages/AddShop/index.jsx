import { Helmet } from 'react-helmet-async';
import Layout from './Layout';

export default function AddShop() {
  return (
    <>
      <Helmet>
        <title>Add Shop - Bubbly</title>
      </Helmet>

      <Layout />
    </>
  );
}
